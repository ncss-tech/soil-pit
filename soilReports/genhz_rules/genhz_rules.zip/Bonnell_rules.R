ghr <- list(
  
  n = c("Ap",
        "A",
        "EB",
        "Bt", 
        "2Bt", 
        "3BCt'", 
        "2C"),
  
  p = c("Ap|A p|AP",
        "^A$|1A|A1|A2",
        "E|B1",
        "^Bt|1Bt t|^BT1|BT2", 
        "^2Bt|2B t|IIB", 
        "BC|B3|IIB3", 
        "^C$|2C|IIC")
  )