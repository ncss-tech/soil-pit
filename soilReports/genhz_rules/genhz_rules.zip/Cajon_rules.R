ghr <- list(
  'Cajon' = list(
    n = c('A', 
          'Bk', 
          'Ck')
    
    p=c('^A',
        '^BA|^Bk|^Bw',
        '^C|BC')
      )
    )