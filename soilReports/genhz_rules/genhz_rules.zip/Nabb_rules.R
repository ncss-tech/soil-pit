ghr <- list(
  n = c("Ap", 
        "Bt", 
        "Btx"),
  
  p = c("Ap",
        "^Bt$", 
        "Btx")
  )