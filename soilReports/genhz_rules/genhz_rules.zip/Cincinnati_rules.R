ghr <- list(
  n = c("Ap", 
        "A", 
        "Bt", 
        "2Btx", 
        "3BCt'", 
        "3C"),
  
  p = c("Ap|A p|AP",
        "^A$|A1|A2",
        "^Bt1|^Bt2|^B21t|^B22T|^Bt$", 
        "^BX|^Bx|^2Btx|^2Bx|^Btx|^IIB", 
        "^3Bt|^3B t|^IIIB|3BC|4BC", 
        "2C|3C|^C$|^C1$|^C2$|IIIC")
  )