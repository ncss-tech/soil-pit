ghr <- list(
  'Carrizo' = list(
    n=c('C', 
        'A', 
        '2Bk', 
        '2Ckq', 
        '2Btkqb', 
        'Bk'),
    
    p=c('C', 
        '^A', 
        'BA|^Bk|^2Bk', 
        'C1$|C2$|^BCk|^2BCk|^Ck|^2Ck|^Cq|^2Cq', 
        'Bt', 
        '^2Bkqb')
  )
)