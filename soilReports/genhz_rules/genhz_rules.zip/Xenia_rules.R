ghr <- list(
  "Xenia"=list(
    n=c("Ap", 
        "E", 
        "Bt", 
        "2Bt", 
        "2BCt", 
        "2Cd", 
        "missing"),
    
    p=c("Ap",
        "E",
        "Bt|BT|1B|B2|B3|B4|BA|B1|B t1|B t2|2B t3|2B t4|2Bk|BW|B&A|Bt3|Btk|2B5|B t3|B t4|B t5|2Bd3",
        "BC|Bc2",
        "^B$",
        "C",
        "Cd",
        "missing")
  )
)