ghr <- list(
  "Miamian"=list(
    n=c("Ap", 
        "A", 
        "E", 
        "Bt", 
        "BC", 
        "C", 
        "Cd", 
        "NA"),
    
    p=c("Ap|AP|1A|A1|A2|A p", 
        "^A$", 
        "E", 
        "BE", 
        "Bt|BT|1B|B2|B3|BA|B1|B t1|B t2", 
        "BC", 
        "^B$", 
        "C", 
        "Cd",
        "NA")
  )
)