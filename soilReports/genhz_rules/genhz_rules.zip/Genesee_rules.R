ghr <- list(
  "Genesee"=list(
    n=c("Ap", 
        "A", 
        "Bw", 
        "C", 
        "Cg", 
        "Ab", 
        "2Bt", 
        "missing"),
    
    p=c("Ap|Ap1|Ap2|AP",
        "^A$|A1|A2|A3",
        "^B", "C|C1|C10|C2|C3|C4|C5|C6|C7|C8|C9",
        "^Cg",
        "Ab",
        "2Bt",
        "missing")
  )
)
