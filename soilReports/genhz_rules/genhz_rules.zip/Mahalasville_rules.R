ghr <- list(
  "Mahalasville"=list(
    n=c("Ap", "Btg", "2Btg", "2BCg", "2Cg", "NA"),
    
    p=c("Ap|AP",
        "Bt|BT|1B|B2|B3|B4|BA|B1|B t1|B t2|2B t3|2B t4|2Bk|BW|B&A|Bt3|Btk",
        "BC",
        "^B$",
        "C",
        "Cd",
        "NA")
  )
)