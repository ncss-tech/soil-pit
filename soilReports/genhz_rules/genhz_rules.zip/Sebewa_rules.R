ghr <- list(
  "Sebewa"=list(
    n=c("Ap", 
        "A", 
        "Bg", 
        "Btg", 
        "2Cg",  
        "missing"),
    
    p=c("Ap|AP",
        "^A$",
        "Bg",        
        "^Btg|BCtg",
        "^C|2C|BCg",
        "missing")
  )
)